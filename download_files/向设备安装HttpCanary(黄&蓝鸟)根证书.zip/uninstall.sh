rm -f /data/data/com.guoshi.httpcanary/cache/HttpCanary.jks
rm -f /sdcard/HttpCanary/certs/HttpCanary.jks