MODDIR=${0%/*}
a=$(find /sys/devices/ -iname "battery" -type d | head -n 1)
b=$(find /sys/class/ -iname "qcom-battery" -type d | head -n 1)
c=$(cat ${a}/charge_full_design)
d=$((${c}/1000))
e=$(cat ${a}/charge_full)
f=$((${e}/1000))
g=$(cat ${a}/cycle_count)
h=$(printf "%d" $((${e}*100/${c})))
if [ -n "${b}" ]; then
i=$(cat ${b}/soh)
j=$(echo "售后检测容量为：${i}%，")
fi
k=$(echo "设计容量为：${d}mAh，当前容量为：${f}mAh，循环次数为：${g}次，健康度为：${h}%，${j}数据来源于内核节点，仅供参考！")
sed -i '/^description=/d' $MODDIR/module.prop
echo "description=${k}" >>$MODDIR/module.prop