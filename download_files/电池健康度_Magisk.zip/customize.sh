################################
# Magisk模块安装脚本
# 使用说明:
# 1. 将文件放入system文件夹
# 2. 在module.prop中填写您的模块信息
# 3. 在此文件中配置和调整
# 4. 如果需要开机执行脚本，请将其添加到post-fs-data.sh或service.sh
# 5. 将其他或修改的系统属性添加到system.prop
#################################

#################################




# 添加您要精简的APP/文件夹目录
# 列出你想在系统中直接替换的所有目录
# 按照以下格式构建列表
# 例如：精简miui云控：/system/app/AnalyticsCore/Analytics.apk
# 转化加入：/system/app/AnalyticsCore
REPLACE="

"





# 默认权限请勿删除
set_perm_recursive $MODPATH 0 0 0755 0644

